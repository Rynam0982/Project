#ifndef VIDE_HPP
#define VIDE_HPP
#include "echiquier.hpp"

class vide : public piece
{

public:
    vide(int, int, int);
    bool is_valid(int,int,echiquier&) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif