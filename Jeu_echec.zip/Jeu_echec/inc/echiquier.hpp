#ifndef ECHEQUIER_HPP
#define ECHEQUIER_HPP
#define TAILLE_ECHIQUIER 8
#include <iostream>
#include "piece.hpp"
#include "pion.hpp"
#include "cavalier.hpp"
#include "fou.hpp"
#include "reine.hpp"
#include "roi.hpp"
#include "tour.hpp"
#include "vide.hpp"
#include <string>

class echiquier
{
private:
    piece *tab_echiquier[TAILLE_ECHIQUIER][TAILLE_ECHIQUIER];

public:
    echiquier();
    ~echiquier();

    void print() const;
    int piece_getcolor(int, int);
    piece* get_piece(int, int);
    void move_piece(int,int,int,int);
};

#endif