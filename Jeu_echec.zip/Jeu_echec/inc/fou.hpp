#ifndef FOU_HPP
#define FOU_HPP
#include "echiquier.hpp"

class fou : public piece
{
public:
    fou(int, int, int);
    bool is_valid(int,int,echiquier&) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif