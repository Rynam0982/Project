#ifndef JEU_HPP
#define JEU_HPP
#include "echiquier.hpp"

class jeu
{
private:
    echiquier jeu_echiquier;
    int round;
    int end;
    int winner;
public:  
    jeu();
    int boucle_jeu();
    int player_move(int,int ,int, int, int);
    void print();
    int is_check();
};

#endif