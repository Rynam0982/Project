#ifndef REINE_HPP
#define REINE_HPP
#include "echiquier.hpp"

class reine : public piece
{
public:
    reine(int, int, int);
    bool is_valid(int,int,echiquier&) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif