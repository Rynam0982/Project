#ifndef PION_HPP
#define PION_HPP
#include "echiquier.hpp"

class pion : public piece
{
private:

public:
    pion(int, int, int);
    bool is_valid(int,int,echiquier&) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif