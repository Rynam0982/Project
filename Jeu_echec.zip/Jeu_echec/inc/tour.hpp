#ifndef TOUR_HPP
#define TOUR_HPP
#include "echiquier.hpp"

class tour : public piece
{

public:
    tour(int, int, int);
    bool is_valid(int,int,echiquier&) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif