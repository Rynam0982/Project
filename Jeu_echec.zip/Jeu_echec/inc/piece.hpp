#ifndef PIECE_HPP
#define PIECE_HPP
#include <iostream>
#include <cstdlib> 
class echiquier;


class piece
{
protected:
    int color, x, y;

public:
    piece(int c,int i,int j):color(c),x(i),y(j){};
    virtual bool is_valid (int ,int, echiquier&) const = 0;
    virtual void print ( )const  = 0;
    virtual void set_piece(int, int)=0;
    virtual int get_color()const=0;

    virtual ~piece() {};
};

#endif