#ifndef CAVALIER_HPP
#define CAVALIER_HPP
#include "echiquier.hpp"

class cavalier : public piece
{
public:
    cavalier(int, int, int);
    bool is_valid(int, int, echiquier &) const override;
    void print() const override;
    int get_color() const override;
    void set_piece(int, int)override;

};

#endif