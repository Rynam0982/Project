
#include "echiquier.hpp"
using namespace std;
echiquier::echiquier()
{
    for (int i = 0; i < TAILLE_ECHIQUIER; i++)
    {
        for (int j = 0; j < TAILLE_ECHIQUIER; j++)
        {

            tab_echiquier[i][j] = new vide(3, i, j);
        }
    }
    // les tours:
    tab_echiquier[0][0] = new tour(0, 0, 0);
    tab_echiquier[0][7] = new tour(0, 0, 7);
    tab_echiquier[7][0] = new tour(1, 7, 0);
    tab_echiquier[7][7] = new tour(1, 7, 7);
    // les cavalier:
    tab_echiquier[0][1] = new cavalier(0, 0, 1);
    tab_echiquier[0][6] = new cavalier(0, 0, 6);
    tab_echiquier[7][1] = new cavalier(1, 7, 1);
    tab_echiquier[7][6] = new cavalier(1, 7, 6);
    // les fou:
    tab_echiquier[0][2] = new fou(0, 0, 2);
    tab_echiquier[0][5] = new fou(0, 0, 5);
    tab_echiquier[7][2] = new fou(1, 7, 2);
    tab_echiquier[7][5] = new fou(1, 7, 5);
    // les roi:
    tab_echiquier[0][3] = new roi(0, 0, 3);
    tab_echiquier[7][3] = new roi(1, 7, 3);
    // les reine:
    tab_echiquier[0][4] = new reine(0, 0, 4);
    tab_echiquier[7][4] = new reine(1, 7, 4);

    for (int i = 0; i < TAILLE_ECHIQUIER; i++)
    {
        tab_echiquier[1][i] = new pion(0, 1, i);
        tab_echiquier[6][i] = new pion(1, 6, i);
    }
};

echiquier::~echiquier()
{

    for (int i = 0; i < TAILLE_ECHIQUIER; i++)
    {
        for (int j = 0; j < TAILLE_ECHIQUIER; j++)
        {

            delete tab_echiquier[i][j];
        }
    }
}

void echiquier::print() const
{
    cout << " a b c d e f g h\n";
    for (int i = 0; i < TAILLE_ECHIQUIER; i++)
    {
        cout << TAILLE_ECHIQUIER - i;
        for (int j = 0; j < TAILLE_ECHIQUIER; j++)

        {
            tab_echiquier[i][j]->print();
        }
        cout << TAILLE_ECHIQUIER - i;
        cout << "\n";
    }
    cout << " a b c d e f g h\n";
}
int echiquier::piece_getcolor(int i, int j)
{
    return tab_echiquier[i][j]->get_color();
}
piece *echiquier::get_piece(int i, int j)
{
    return tab_echiquier[i][j];
}

void echiquier::move_piece(int from_i, int from_j, int to_i, int to_j)
{   
    delete tab_echiquier[to_i][to_j];
    tab_echiquier[to_i][to_j] = tab_echiquier[from_i][from_j];

    tab_echiquier[from_i][from_j] = new vide(3, from_i, from_j);
    tab_echiquier[to_i][to_j]->set_piece(to_i,to_j);
}
