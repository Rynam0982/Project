#include "roi.hpp"
using namespace std;
roi::roi(int couleur, int i, int j) : piece(couleur, i, j) {};
void roi::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265A " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;31m" << "\u265A " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265A " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;91m" << "\u265A " << "\e[0m";
        }
    }
}
bool roi::is_valid(int i, int j, echiquier &t_echiquier) const
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {
       if((abs(x - i)<2)&& abs(y - i)<2){
        if ((i - x != 0 && j - y == 0) || (i - x == 0 && j - y != 0))
        { // elle agis comme une tour

            int obstacle = 1;
            if ((x - i) < 0)
            {
                if (t_echiquier.piece_getcolor(x + 1, y) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }
                return 1;
            }

            if ((y - j) < 0)
            {

                if (t_echiquier.piece_getcolor(x, y + 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }
                return 1;
            }

            if ((y - j) > 0)
            {

                if (t_echiquier.piece_getcolor(x, y - 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }
                return 1;
            }
            if ((x - i) > 0)
            {

                if (t_echiquier.piece_getcolor(x - 1, y) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }
                return 1;
            }
        }
        else if ((abs(x - i) / abs(y - j) == 1) && (abs(x - i) % abs(y - j) == 0))
        {
            // elle agis comme un fou

            int obstacle = 1;
            if ((x - i) < 0 && (y - j) < 0)
            {

                if (t_echiquier.piece_getcolor(x + 1, y + 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }

                return 1;
            }
            if ((x - i) > 0 && (y - j) > 0)
            {

                if (t_echiquier.piece_getcolor(x - 1, y - 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }

                return 1;
            }

            if ((x - i) > 0 && (y - j) < 0)
            {

                if (t_echiquier.piece_getcolor(x - 1, y + 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }

                return 1;
            }
            if ((x - i) < 0 && (y - j) > 0)
            {

                if (t_echiquier.piece_getcolor(x + 1, y - 1) ==13)
                {
                    obstacle = 0;
                    return obstacle;
                }

                return 1;
            }
        }
        return 0;
    }
    }
    return 0;
}
int roi::get_color() const
{
    return color;
}
void roi::set_piece(int i, int j)
{
    x = i;
    y = j;
};
