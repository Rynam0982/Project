#include"jeu.hpp"
#include"echiquier.hpp"
int main(){
//creaion de boucle de jeu
jeu game;

while (!game.boucle_jeu()){
}
//std::cout<<"Gagnat"<<game.get_winner();




//game.player_move(6,0,6,7,1);
//game.print();

/*game.player_move(2,0,3,2,1);
game.print();
*/


    return 0;
}