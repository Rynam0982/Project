#include "jeu.hpp"
using namespace std;
// player==color

jeu::jeu() : jeu_echiquier(), round(0), end(0), winner(-1) {};

int jeu ::player_move(int from_ligne, int from_colonne, int to_ligne, int to_colonne, int player)
{
    piece *ma_piece = jeu_echiquier.get_piece(from_ligne, from_colonne);
    cout << ma_piece->get_color();
    //if (ma_piece->get_color() == player)
    //{
        if (ma_piece->is_valid(to_ligne, to_colonne, this->jeu_echiquier))
        {
            jeu_echiquier.move_piece(from_ligne, from_colonne, to_ligne, to_colonne);
            round++;
            return 1;
        }
        else
        {
            cout << "la piece ne peut pas faire ce mouvement\n";
            return 0;
        }
    //}
   // else
   // {
   //     cout << "mauvaise piece\n";
//return 0;
   // }
   // return 0;
}
int jeu::boucle_jeu()
{
    int from_x, from_y, to_x, to_y;
    int end = 0;
    while (end != 1)
    {
        cout<<"player:"<<round%2<<"\n";
        print();
        cout << "le x et y de la piece a deplacer\n";
        cin >> from_x;
        cin >> from_y;
        cout << "vers ou la deplacer:\n";
        cin >> to_x;
        cin >> to_y;
        while (player_move(from_x, from_y, to_x, to_y, round % 2) == 0)
        {
            cout << "le x et y de la piece a deplacer\n";
            cin >> from_x;
            cin >> from_y;
            cout << "vers ou la deplacer:\n";
            cin >> to_x;
            cin >> to_y;
        };
        round++;
    }
    return 1;
}

void jeu::print()
{
    jeu_echiquier.print();
}
