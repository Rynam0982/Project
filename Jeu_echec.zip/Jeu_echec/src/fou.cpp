#include "fou.hpp"
#define TAILLE_ECHIQUIER 8
using namespace std;
fou::fou(int couleur, int i, int j) : piece(couleur, i, j) {};
void fou::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265D " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;31m" << "\u265D " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265D " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;91m" << "\u265D " << "\e[0m";
        }
    }
}
bool fou::is_valid(int i, int j, echiquier &t_echiquier) const // je dois encore verifié qu'il ya pas de piece sur la route avec un boucle qui sincremente et qui check  a chaque fois
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {

        if ((abs(x - i) / abs(y - j) == 1) && (abs(x - i) % abs(y - j) == 0))

        {
            int obstacle = 1;
            if ((x - i) < 0 && (y - j) < 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x + a, y + a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) > 0 && (y - j) > 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x - a, y - a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }

            if ((x - i) > 0 && (y - j) < 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x - a, y + a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) < 0 && (y - j) > 0)
            {
                cout << "walu?\n";
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x + a, y - a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
        }
        return 0;
    }
    return 0;
}
int fou::get_color() const
{
    return color;
}
void fou::set_piece(int i, int j)
{
    x = i;
    y = j;
};
