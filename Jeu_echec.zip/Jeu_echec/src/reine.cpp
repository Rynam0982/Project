#include "reine.hpp"
using namespace std;
reine::reine(int couleur, int i, int j) : piece(couleur, i, j) {};
void reine::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265B " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;31m" << "\u265B " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265B " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;91m" << "\u265B " << "\e[0m";
        }
    }
}
bool reine::is_valid(int i, int j, echiquier &t_echiquier) const
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {

        if ((i - x != 0 && j - y == 0) || (i - x == 0 && j - y != 0))
        { // elle agis comme une tour
           

            int obstacle = 1;
            if ((x - i) < 0)
            {

                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x + a, y) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }

            if ((y - j) < 0)
            {

                for (int a = 1; a <= abs(y - j); a++)
                {

                    if (t_echiquier.piece_getcolor(x, y + a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }

            if ((y - j) > 0)
            {
                for (int a = 1; a <= abs(y - j); a++)
                {

                    if (t_echiquier.piece_getcolor(x, y - a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) > 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x - a, y) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
        }
        else if ((abs(x - i) / abs(y - j) == 1) && (abs(x - i) % abs(y - j) == 0))
        {
            
            int obstacle = 1;
            if ((x - i) < 0 && (y - j) < 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x + a, y + a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) > 0 && (y - j) > 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x - a, y - a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }

            if ((x - i) > 0 && (y - j) < 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x - a, y + a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) < 0 && (y - j) > 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {
                    if (t_echiquier.piece_getcolor(x + a, y - a) != 3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
        }
        return 0;
    }
    return 0;
}
    int reine::get_color() const
    {
        return color;
    }
    void reine::set_piece(int i, int j)
    {
        x = i;
        y = j;
    };