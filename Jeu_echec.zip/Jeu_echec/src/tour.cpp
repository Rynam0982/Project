#include "tour.hpp"
using namespace std;
tour::tour(int couleur, int i, int j) : piece(couleur, i, j) {};
void tour::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265C " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;31m" << "\u265C " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265C " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;91m" << "\u265C " << "\e[0m";
        }
    }
}
int tour::get_color() const
{
    return color;
}
bool tour::is_valid(int i, int j, echiquier &t_echiquier) const
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {
      
        if ((i - x != 0 && j - y == 0) || (i - x == 0 && j - y != 0))
        {
          

            int obstacle = 1;
            if ((x - i) < 0)
            {
                

                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x + a, y) !=3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            
            if ((y - j) < 0)
            {
        
                for (int a = 1; a <= abs(y - j); a++)
                {

                    if (t_echiquier.piece_getcolor(x, y + a)  !=3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }

            if ((y - j) > 0)
            {
                for (int a = 1; a <= abs(y - j); a++)
                {

                    if (t_echiquier.piece_getcolor(x, y - a)  !=3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
            if ((x - i) > 0)
            {
                for (int a = 1; a <= abs(x - i); a++)
                {

                    if (t_echiquier.piece_getcolor(x - a, y)  !=3)
                    {
                        obstacle = 0;
                        return obstacle;
                    }
                }
                return 1;
            }
        }
        return 0;
    }
    return 0;
}
void tour::set_piece(int i, int j)
{
    x = i;
    y = j;
};
