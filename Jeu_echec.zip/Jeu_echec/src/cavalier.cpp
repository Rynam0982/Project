#include "cavalier.hpp"

using namespace std;
cavalier::cavalier(int couleur, int i, int j) : piece(couleur, i, j) {};
void cavalier::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265E " << "\e[0m";
        }
        else
        {
            cout << "\e[48;5;0"<< "\e[38;5;31m" << "\u265E " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265E " << "\e[0m";
        }
        else
        {
            cout << "\e[48;5;0"<< "\e[38;5;91m" << "\u265E " << "\e[0m";
        }
    }
}

int cavalier::get_color() const
{
    return color;
}
void cavalier::set_piece(int i, int j)
{
    x = i;
    y = j;
};

bool cavalier::is_valid(int i, int j, echiquier &t_echiquier) const
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {
        if (((i == x + 2) && (j == y + 1)) || ((i == x + 2) && (j == y - 1)) || ((i == x - 2) && (j == y + 1)) || ((i == x - 2) && (j == y - 1)) || ((j == y + 2) && (i == x + 1)) || ((j == y + 2) && (i == x - 1)) || ((j == y - 2) && (i == x + 1)) || ((j == y - 2) && (i == x - 1)))
        {
            if (t_echiquier.piece_getcolor(i, j) != color)
                return 1;
        }
    }

    return 0;
}
