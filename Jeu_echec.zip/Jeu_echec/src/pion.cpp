#include "pion.hpp"
using namespace std;
pion::pion(int couleur, int i, int j) : piece(couleur, i, j) {};
void pion::print() const
{

    if (color == 1)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;31m" << "\u265F " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;31m" << "\u265F " << "\e[0m";
        }
    }
    if (color == 0)
    {
        if ((x + y) % 2 == 0)
        {
            cout << "\e[48;5;255m" << "\e[38;5;91m" << "\u265F " << "\e[0m";
        }
        else
        {
            cout << "\e[38;5;91m" << "\u265F " << "\e[0m";
        }
    }
}
bool pion::is_valid(int i, int j, echiquier &t_echiquier) const
{

    if (i >= 0 && j >= 0 && i < TAILLE_ECHIQUIER && j < TAILLE_ECHIQUIER)
    {

        if (color == 1)
        {

            if (((x - i) == 1))
            {

                if (abs(y - j) == 1) // le cas ou il mange
                {

                    if ((t_echiquier.piece_getcolor(i, j) != color) && (t_echiquier.piece_getcolor(i, j) != 3))
                    {
                        return 1;
                    }
                }
                if (y - j == 0)
                {

                    if (t_echiquier.piece_getcolor(i, j) == 3)
                    {
                        return 1;
                    }
                }
            }
            if (((x - i) == 2) && (x == 6))
            {

                if (t_echiquier.piece_getcolor(i, j) == 3)
                {
                    return 1;
                }
            }
        }
        if (color == 0)
        {

            if (((i - x) == 1))
            {

                if (abs(y - j) == 1) // le cas ou il mange
                {

                    if ((t_echiquier.piece_getcolor(i, j) != color) && (t_echiquier.piece_getcolor(i, j) != 3))
                    {
                        return 1;
                    }
                }
                if (y - j == 0)
                {

                    if (t_echiquier.piece_getcolor(i, j) == 3)
                    {
                        return 1;
                    }
                }
            }
            if (((i - x) == 2) && (x == 1))
            {

                if (t_echiquier.piece_getcolor(i, j) == 3)
                {
                    return 1;
                }
            }
        }
    }
    return 0;
}

int pion::get_color() const
{
    return color;
}
void pion::set_piece(int i, int j)
{
    x = i;
    y = j;
};
