#include "vide.hpp"
using namespace std;
vide::vide(int couleur, int i, int j) : piece(couleur, i, j) {};
void vide::print() const
{
        if((x+y)%2==0){
         cout <<"\e[48;5;255m"<<"\e[38;5;31m"<<"  "<<"\e[0m";
        }
        else{
         cout <<"\e[38;5;31m"<<"  "<<"\e[0m";
        }
    }
bool vide::is_valid(int i, int j, echiquier &t_echiquier) const
{
 return false;
    }
int vide::get_color() const {
    return color;
}
 void vide::set_piece(int i, int j){
    x=i;
    y=j;
 };